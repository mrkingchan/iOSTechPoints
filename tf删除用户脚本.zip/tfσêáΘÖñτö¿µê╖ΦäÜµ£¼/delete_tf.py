# -*- coding: utf-8 -*-

"""
根据配置文件删除所有测试人员
用法：cd到DelTF目录 然后运行命令
python3 delete_tf.py -f config/config.json
需要安装环境：
    pythn3 环境
    pip3 环境
    pip3 install requests
    pip3 install PyJWT
    pip3 install argparse
"""

import os
import jwt
import json
import time
import requests
import argparse


def get_config(path):
    """获取配置文件

    Arguments:
        path {str} -- 配置文件路径

    Returns:
        dict -- 返回配置文件的dist
    """
    with open(path, "r") as f:
        config = json.load(f)
    return config


def gen_token():
    """生成JWTtoken

    Returns:
        string -- 生成的toket
    """
    headers = {
        'alg': "ES256",
        "kid": config["kid"],
        "typ": "typ"
    }

    claims = {
        'iss': config["iss"],
        'exp': int(time.time()) + 1200,
        'aud': 'appstoreconnect-v1',
    }

    key_path = os.path.join(config_dir, config["keyFile"])
    with open(key_path, 'r') as f:
        key = f.read()

    token = jwt.encode(claims, key, algorithm="ES256", headers=headers).decode('ascii')
    return token


def get_headers():
    """拼接请求头

    Returns:
        dict -- 返回拼接好的请求头
    """
    headers = {"Authorization": 'Bearer {}'.format(gen_token()), "Content-Type": "application/json"}
    return headers


def get_app_id(name):
    """根据应用名称获取应用ID

    Arguments:
        name {str} -- 应用名称

    Returns:
        {str} -- 返回应用ID
    """

    url = "https://api.appstoreconnect.apple.com/v1/apps?filter[name]={name}".format(name=name)
    response = requests.get(url, headers=get_headers())
    code = response.status_code

    if code == 200:
        outs_dict = response.json()
        return outs_dict['data'][0]['id']
    else:
        print("get_app_id error code is {}".format(code))
        return code


def get_tester_list(app_id, url="", limit=200):
    """根据应用ID获取测试人员

    Arguments:
        app_id {str} -- 应用ID

    Keyword Arguments:
        url {str} -- 链接，默认为空，获取第一个两百个人员，后面根据返回的第三个参数next_link传入，来循环获取 (default: {""})

        limit {int} -- 请求数量，默认为200 (default: {200})

    Returns:
        请求识别返回错误码
        请求成功返回：
            tester_list：200个测试人员
            total：测试人员总数量
            next_link： 下一页的链接

    """
    if url == "":
        url = "https://api.appstoreconnect.apple.com/v1/betaTesters"
        response = requests.get(url, headers=get_headers(), params={'limit': limit, 'filter[apps]': app_id})
    else:
        url = url if limit == 200 else url.replace("200", str(limit))
        response = requests.get(url, headers=get_headers())
    code = response.status_code

    if code == 200:
        outs_dict = response.json()
        tester_list = [data["id"] for data in outs_dict["data"]]
        tester_list = [{"type": "betaTesters", "id": tester_id} for tester_id in tester_list]
        total = outs_dict["meta"]["paging"]["total"]

        next_link = None
        if "next" in outs_dict["links"]:
            next_link = outs_dict["links"]["next"]
        return tester_list, total, next_link
    else:
        print("get_tester_list error code is {}".format(code))
        print(response.text)
        return code


def delete_tester(app_id, tester_id_list):
    """删除测试人员

    Arguments:
        app_id {str} -- 应用ID
        tester_id_list {list} -- 测试人员的列表
    """

    url = "https://api.appstoreconnect.apple.com/v1/apps/{id}/relationships/betaTesters".format(id=app_id)
    payload = {"data": tester_id_list}
    response = requests.delete(url, headers=get_headers(), data=json.dumps(payload))
    code = response.status_code

    if code == 204:
        print("成功删除{0}个测试人员".format(len(tester_id_list)))
    else:
        print("delete error code is {}".format(code))
    return code


if __name__ == "__main__":
    # 读取输入参数
    ap = argparse.ArgumentParser()
    ap.add_argument("-f", "--config", required=True, help="配置文件路径")
    args = ap.parse_args()

    # 配置文件所在文件夹的目录
    config_dir = os.path.dirname(os.path.abspath(args.config))

    # 遍历所有应用
    for config in get_config(args.config):
        app_name = config["appName"]
        app_id = get_app_id(app_name)

        print("获取到应用{}ID为: {}".format(app_name, app_id))
        tester_list_all = []
        next_link = ""
        limit = 200

        # 循环获取所有测试人员
        while True:
            result = get_tester_list(app_id, url=next_link, limit=limit)
            if isinstance(result, int):
                break
            tester_list, total, next_link = result
            tester_list_all.extend(tester_list)
            if next_link is None:
                break
            else:
                remaining = total - len(tester_list_all)
                limit = 200 if remaining >= 200 else remaining

        print("获取到应用{}共有{}个测试人员, 正在进行删除...".format(app_name, len(tester_list_all)))
        delete_tester(app_id, tester_list_all)
        print('-*-*'*20, '\n')
