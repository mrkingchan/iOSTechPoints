//
//  BookAdapter.h
//  MVA
//
//  Created by mac on 2020/7/3.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BookCell.h"
#import "BookModel.h"

NS_ASSUME_NONNULL_BEGIN

/**
    同一对view-model，可以有不同的adapter
 
    不同的view-model，也可以有不同的adapter
 */
@interface BookAdapter : NSObject <BookCellDelegate>

@property (nonatomic) BookCell *view;
@property (nonatomic) BookModel *model;

@end

NS_ASSUME_NONNULL_END
