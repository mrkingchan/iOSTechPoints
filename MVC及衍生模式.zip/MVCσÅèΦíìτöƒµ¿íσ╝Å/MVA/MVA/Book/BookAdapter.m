//
//  BookAdapter.m
//  MVA
//
//  Created by mac on 2020/7/3.
//  Copyright © 2020 mac. All rights reserved.
//

#import "BookAdapter.h"

@implementation BookAdapter

- (void)setView:(BookCell *)view {
    _view = view;
    [self updateUI];
}

- (void)updateUI {
    self.view.upLabel.text = self.model.title;
    self.view.downLabel.text = self.model.subtitle;
    self.view.collectButton.selected = self.model.isSelected;
    self.view.delegate = self;
}

//MARK:-    BookCellDelegate

- (void)cell:(BookCell *)cell didClickCollectButton:(UIButton *)button {
    self.model.isSelected = !self.model.isSelected;
    cell.collectButton.selected = self.model.isSelected;
}

@end
