//
//  BookViewModel.h
//  MVVM
//
//  Created by mac on 2020/7/1.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

//  ViewModel引用Model，但不引用View。
@interface BookViewModel : NSObject

@property (nonatomic) NSString *title;
@property (nonatomic) NSString *subtitle;

@property (nonatomic) NSURL *image;

@property (nonatomic) BOOL isSelected;

- (void)collect;

+ (void)fetchWithCompletion:(void (^)(NSError* _Nullable, NSMutableArray<BookViewModel *> * _Nullable))completion;

@end

NS_ASSUME_NONNULL_END
