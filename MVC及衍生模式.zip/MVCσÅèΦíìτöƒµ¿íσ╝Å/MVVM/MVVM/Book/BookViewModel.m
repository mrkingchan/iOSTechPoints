//
//  BookViewModel.m
//  MVVM
//
//  Created by mac on 2020/7/1.
//  Copyright © 2020 mac. All rights reserved.
//

#import "BookViewModel.h"
#import "BookModel.h"

@interface BookViewModel ()
@property (nonatomic) BookModel *model;
@end

@implementation BookViewModel

//  值转换器，可做更多的转换
- (NSString *)title {
    return self.model.title;
}

- (NSString *)subtitle {
    return self.model.subtitle;
}

- (void)collect {
    self.isSelected = !self.isSelected;
}

+ (void)fetchWithCompletion:(void (^)(NSError* _Nullable, NSMutableArray<BookViewModel *> * _Nullable))completion {
    //  模拟耗时操作
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSString *path = [[NSBundle mainBundle] pathForResource:@"Book" ofType:@"json"];
        NSData *data = [NSData dataWithContentsOfFile:path];
        
        NSError *error = nil;
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
        if (error) {
            if (completion) completion(error, nil);
            return;
        }
        NSArray<NSDictionary *> *books = dict[@"books"];
        NSMutableArray<BookViewModel *> *models = [NSMutableArray new];
        for (NSDictionary *dict in books) {
            BookModel *model = [BookModel modelFromDict:dict];
            BookViewModel *viewModel = [BookViewModel new];
            viewModel.model = model;
            [models addObject:viewModel];
        }
        //
        if (completion) completion(nil, models);
    });
}

@end
