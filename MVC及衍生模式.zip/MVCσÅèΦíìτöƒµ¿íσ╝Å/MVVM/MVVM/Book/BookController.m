//
//  BookController.m
//  MVP
//
//  Created by mac on 2020/6/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import "BookController.h"
#import "BookCell.h"
#import "BookViewModel.h"

@interface BookController () <UITableViewDataSource, UITableViewDelegate> {
    NSMutableArray<BookViewModel *> *_models;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation BookController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UINib *nib = [UINib nibWithNibName:@"BookCell" bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:@"ID"];
    
    [self loadData];
}

- (void)loadData {
    [BookViewModel fetchWithCompletion:^(NSError * _Nullable error, NSMutableArray<BookViewModel *> * _Nullable models) {
        if (error) return;
        _models = models;
        [self.tableView reloadData];
    }];
}

//MARK:-    数据源 + 委托

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _models.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    BookViewModel *model = _models[indexPath.row];
    BookCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID" forIndexPath:indexPath];
    //  属性绑定
    cell.upLabel.text = model.title;
    cell.downLabel.text = model.subtitle;
    cell.collectButton.selected = model.isSelected;
    //  行为绑定
    __weak typeof (cell) weak_cell = cell;
    cell.collectCallback = ^{
        [model collect];
        //  直接方式
        weak_cell.collectButton.selected = model.isSelected;
        //  reload是间接方式，不符合MVVM的设计
//        [weak_tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    };
    return cell;
}

@end
