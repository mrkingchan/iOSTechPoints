//
//  BookPresenter.h
//  MVP
//
//  Created by mac on 2020/6/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BookPresenter : UIViewController

@end

NS_ASSUME_NONNULL_END
