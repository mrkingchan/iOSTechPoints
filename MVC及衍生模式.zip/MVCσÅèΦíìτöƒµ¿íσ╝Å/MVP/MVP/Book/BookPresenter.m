//
//  BookPresenter.m
//  MVP
//
//  Created by mac on 2020/6/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import "BookPresenter.h"
#import "BookCell.h"
#import "BookModel.h"

/**
    这里的BookPresenter只是个名字而已，换成BookViewController是完全可以的。
 
    即使名字为BookViewModel，也不是MVVM模式，还是MVP模式。
    
    要理解MVP中组件的职责、组件的交互方式。
 */
@interface BookPresenter () <UITableViewDataSource, UITableViewDelegate, BookCellDelegate> {
    NSMutableArray<BookModel *> *_models;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation BookPresenter

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UINib *nib = [UINib nibWithNibName:@"BookCell" bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:@"ID"];
    
    [self loadData];
}

- (void)loadData {
    [BookModel fetchBooksWithCompletion:^(NSError * _Nullable error, NSMutableArray<BookModel *> * _Nullable models) {
        if (error) return;
        _models = models;
        [self.tableView reloadData];
    }];
}

//MARK:-    数据源 + 委托

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _models.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    BookModel *model = _models[indexPath.row];
    BookCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID" forIndexPath:indexPath];
    cell.upLabel.text = model.title;
    cell.downLabel.text = model.subtitle;
    cell.collectButton.selected = model.isSelected;
    cell.delegate = self;
    return cell;
}

//MARK:-    BookCellDelegate

- (void)cell:(BookCell *)cell didClickCollectButton:(UIButton *)button {
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    BookModel *model = _models[indexPath.row];
    model.isSelected = !model.isSelected;
    [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}

@end
