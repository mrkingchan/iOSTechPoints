//
//  BookCell.m
//  MVP
//
//  Created by mac on 2020/6/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import "BookCell.h"

@interface BookCell ()

@property (weak, nonatomic) IBOutlet UIImageView *logoImageView;
@property (weak, nonatomic) IBOutlet UILabel *upLabel;
@property (weak, nonatomic) IBOutlet UILabel *downLabel;
@property (weak, nonatomic) IBOutlet UIButton *collectButton;

@end

@implementation BookCell

- (void)setModel:(BookModel *)model {
    _model = model;
    self.upLabel.text = model.title;
    self.downLabel.text = model.subtitle;
    self.collectButton.selected = model.isSelected;
}

- (IBAction)didClickCollectButton:(UIButton *)sender {
    if ([self.delegate respondsToSelector:@selector(cell:didClickCollectButton:)]) {
        [self.delegate cell:self didClickCollectButton:sender];
    }
}


@end
