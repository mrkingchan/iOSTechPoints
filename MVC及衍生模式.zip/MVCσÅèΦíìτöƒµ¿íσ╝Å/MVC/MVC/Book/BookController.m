//
//  BookController.m
//  MVP
//
//  Created by mac on 2020/6/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import "BookController.h"
#import "BookCell.h"

@interface BookController () <UITableViewDataSource, UITableViewDelegate, BookCellDelegate> {
    NSMutableArray<BookModel *> *_models;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation BookController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UINib *nib = [UINib nibWithNibName:@"BookCell" bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:@"ID"];
    
    [self loadData];
}

- (void)loadData {
    //  不会造成循环引用，但会造成BookController在Block回调后才销毁
    [BookModel fetchBooksWithCompletion:^(NSError * _Nullable error, NSMutableArray<BookModel *> * _Nullable models) {
        if (error) return;
        _models = models;
        [self.tableView reloadData];
    }];
}

//MARK:-    数据源 + 委托

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _models.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    BookModel *model = _models[indexPath.row];
    BookCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID" forIndexPath:indexPath];
    cell.model = model;
    cell.delegate = self;
    return cell;
}

//MARK:-    BookCellDelegate

- (void)cell:(BookCell *)cell didClickCollectButton:(UIButton *)button {
    BookModel *model = cell.model;
    model.isSelected = !model.isSelected;
    cell.model = model;
}

@end
