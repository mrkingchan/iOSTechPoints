//
//  BookCell.h
//  MVP
//
//  Created by mac on 2020/6/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BookModel.h"
@protocol BookCellDelegate;

NS_ASSUME_NONNULL_BEGIN

//  在View中会出现Model
@interface BookCell : UITableViewCell

@property (weak, nonatomic) id<BookCellDelegate> delegate;

@property (nonatomic) BookModel *model;

@end


@protocol BookCellDelegate <NSObject>

- (void)cell:(BookCell *)cell didClickCollectButton:(UIButton *)button;

@end

NS_ASSUME_NONNULL_END
