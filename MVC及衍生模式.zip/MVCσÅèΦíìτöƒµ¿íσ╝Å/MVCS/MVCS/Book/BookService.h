//
//  BookService.h
//  MVCS
//
//  Created by mac on 2020/6/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BookModel.h"

NS_ASSUME_NONNULL_BEGIN

//  从网络、数据库获取数据并转换成Model，给Controller使用。
@interface BookService : NSObject

+ (void)fetchBooksWithCompletion:(void (^)(NSError* _Nullable, NSMutableArray<BookModel *> * _Nullable))completion;

@end

NS_ASSUME_NONNULL_END
