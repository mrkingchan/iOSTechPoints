//
//  Worker.h
//  Adapter
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Worker : NSObject

@property (nonatomic) NSString *name;
@property (nonatomic) NSInteger age;

- (void)work;

@end

NS_ASSUME_NONNULL_END
