//
//  ObjectAdapter.m
//  Adapter
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ObjectAdapter.h"

@implementation ObjectAdapter

- (void)run {
    [self.worker work];
}

@end
