//
//  Worker.m
//  Factory
//
//  Created by mac on 2020/7/15.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Doctor.h"
#import "Nurse.h"

@implementation Worker

+ (instancetype)createDoctor {
    return [Doctor new];
}

+ (instancetype)createNurse {
    return [Nurse new];
}

@end
