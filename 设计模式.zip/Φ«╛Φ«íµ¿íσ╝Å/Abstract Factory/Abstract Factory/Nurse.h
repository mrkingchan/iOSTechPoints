//
//  Nurse.h
//  Factory
//
//  Created by mac on 2020/7/15.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Worker.h"

NS_ASSUME_NONNULL_BEGIN

@interface Nurse : Worker

@end

NS_ASSUME_NONNULL_END
