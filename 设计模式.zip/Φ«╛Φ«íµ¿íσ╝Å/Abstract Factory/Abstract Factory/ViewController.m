//
//  ViewController.m
//  Abstract Factory
//
//  Created by mac on 2020/7/15.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "Worker.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
        
    Worker *w = [Worker createNurse];
    [w work];
    puts(__func__);
}


@end
