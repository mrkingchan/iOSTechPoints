//
//  Worker.h
//  Factory
//
//  Created by mac on 2020/7/15.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

//  定义抽象接口
@interface Worker : NSObject

+ (instancetype)createDoctor;

+ (instancetype)createNurse;

- (void)work;

@end

NS_ASSUME_NONNULL_END
