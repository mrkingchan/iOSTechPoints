//
//  NotifyCenter.m
//  Observer
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "NotifyCenter.h"
#import <objc/message.h>

//MARK:-    NotifyModel

@interface NotifyModel: NSObject
@property id observer;
@property SEL aSelector;
@property id object;
@end

@implementation NotifyModel
@end

//MARK:-    NotifyCenter

@interface NotifyCenter () {
    NSMutableArray<NotifyModel *> *_lists;
}
@end

@implementation NotifyCenter

- (instancetype)init {
    self = [super init];
    if (self) {
        _lists = [NSMutableArray new];
    }
    return self;
}

- (void)addObserver:(id)observer selector:(SEL)aSelector object:(nullable id)object {
    NotifyModel *model = [NotifyModel new];
    model.observer = observer;
    model.aSelector = aSelector;
    model.object = object;
    [_lists addObject:model];
}

- (void)removeObserver:(id)observer {
    int i = 0;
    while (i < _lists.count) {
        NotifyModel *model = _lists[i];
        if (model.observer == observer) {
            [_lists removeObject:model];
        } else {
            i++;
        }
    }
}

- (void)post:(nullable id)object {
    for (NotifyModel *model in _lists) {
        ((void (*)(id, SEL, id))objc_msgSend)(model.observer, model.aSelector, model.object);
    }
}

@end
