//
//  ViewController.h
//  Prototype
//
//  Created by mac on 2020/7/14.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

