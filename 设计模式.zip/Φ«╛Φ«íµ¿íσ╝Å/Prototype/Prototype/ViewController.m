//
//  ViewController.m
//  Prototype
//
//  Created by mac on 2020/7/14.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "Worker.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    Worker *a = [Worker new];
    a.name = @"Tom";
    a.age = 12;
    Worker *b = [a copy];

}


@end
