//
//  Worker.m
//  Prototype
//
//  Created by mac on 2020/7/14.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Worker.h"

@implementation Worker

- (id)copyWithZone:(NSZone *)zone {
    Worker *a = [[[self class] allocWithZone:zone] init];
    a.name = [self.name copyWithZone:zone];
    a.age = self.age;
    return a;
}

@end
