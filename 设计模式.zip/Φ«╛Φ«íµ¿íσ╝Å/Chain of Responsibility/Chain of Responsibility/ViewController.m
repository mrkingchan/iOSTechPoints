//
//  ViewController.m
//  Chain of Responsibility
//
//  Created by mac on 2020/7/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "DesignWorker.h"
#import "CodingWorker.h"
#import "TestWorker.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    DesignWorker *d = [DesignWorker new];
    d.type = WorkTypeDesign;
    CodingWorker *c = [CodingWorker new];
    c.type = WorkTypeCoding;
    TestWorker *t = [TestWorker new];
    t.type = WorkTypeTest;
    
    [d setNext:c];
    [c setNext:t];
    
    [d work:@"Hello World" type:WorkTypeCoding];
}


@end
