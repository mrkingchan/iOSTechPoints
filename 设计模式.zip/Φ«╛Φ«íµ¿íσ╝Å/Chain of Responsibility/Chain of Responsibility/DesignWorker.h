//
//  DesignWorker.h
//  Chain of Responsibility
//
//  Created by mac on 2020/7/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Worker.h"

NS_ASSUME_NONNULL_BEGIN

@interface DesignWorker : Worker

@end

NS_ASSUME_NONNULL_END
