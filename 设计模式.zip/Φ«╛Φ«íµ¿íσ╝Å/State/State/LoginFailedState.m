//
//  LoginFailedState.m
//  State
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "LoginFailedState.h"

@implementation LoginFailedState

@synthesize loginingEnabled;
@synthesize loginSuccessEnabled;
@synthesize loginFailedEnabled;

- (instancetype)init {
    self = [super init];
    if (self) {
        loginingEnabled = NO;
        loginSuccessEnabled = NO;
        loginFailedEnabled = YES;
    }
    return self;
}

- (void)login:(Context *)ctx {
    NSAssert(NO, @"不可用");
}

- (void)loginFailed:(Context *)ctx {
    puts(">>> 成功失败");
}

- (void)loginSuccess:(Context *)ctx {
    NSAssert(NO, @"不可用");
}

@end
