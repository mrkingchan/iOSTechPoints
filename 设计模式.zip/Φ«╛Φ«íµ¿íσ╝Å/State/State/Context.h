//
//  Context.h
//  State
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LoginingState.h"
#import "LoginSuccessState.h"
#import "LoginFailedState.h"

NS_ASSUME_NONNULL_BEGIN

@interface Context : NSObject

@property (class, readonly) LoginingState *loginingState;
@property (class, readonly) LoginSuccessState *loginSuccessState;
@property (class, readonly) LoginFailedState *loginFailedState;

@property id<State> state;

- (void)login;
- (void)loginSuccess;
- (void)loginFailed;

@end

NS_ASSUME_NONNULL_END
