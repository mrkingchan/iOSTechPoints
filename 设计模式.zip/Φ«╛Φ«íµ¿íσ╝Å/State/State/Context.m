//
//  Context.m
//  State
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Context.h"

@implementation Context

+ (LoginingState *)loginingState {
    static LoginingState *state = nil;
    if (state == nil) {
        state = [LoginingState new];
    }
    return state;
}

+ (LoginSuccessState *)loginSuccessState {
    static LoginSuccessState *state = nil;
    if (state == nil) {
        state = [LoginSuccessState new];
    }
    return state;
}

+ (LoginFailedState *)loginFailedState {
    static LoginFailedState *state = nil;
    if (state == nil) {
        state = [LoginFailedState new];
    }
    return state;
}

- (void)login {
    [self.state login:self];
}

- (void)loginSuccess {
    [self.state loginSuccess:self];
}

- (void)loginFailed {
    [self.state loginFailed:self];
}

@end
