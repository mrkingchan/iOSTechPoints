//
//  State.h
//  State
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Context;

NS_ASSUME_NONNULL_BEGIN

@protocol State <NSObject>

@property (readonly) BOOL loginingEnabled;
@property (readonly) BOOL loginSuccessEnabled;
@property (readonly) BOOL loginFailedEnabled;

- (void)login:(Context *)ctx;
- (void)loginSuccess:(Context *)ctx;
- (void)loginFailed:(Context *)ctx;

@end

NS_ASSUME_NONNULL_END
