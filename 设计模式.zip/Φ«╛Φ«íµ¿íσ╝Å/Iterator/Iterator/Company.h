//
//  Company.h
//  Iterator
//
//  Created by mac on 2020/7/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Worker.h"
#import "Iterator.h"

NS_ASSUME_NONNULL_BEGIN

@interface Company : NSObject

- (void)addWorker:(Worker *)worker;

- (id<Iterator>)iterate;

@end

NS_ASSUME_NONNULL_END
