//
//  TestWorker.m
//  Mediator
//
//  Created by mac on 2020/7/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import "TestWorker.h"

@implementation TestWorker

- (void)test:(NSInteger)num {
    printf("--- %s 测试完成\n", [self.name UTF8String]);
    if (num != 0) {
        printf("--- 发现bug，反馈给编码人员\n");
        [self.mediator code:num - 1];
    } else {
        printf("--- 没有bug\n");
    }
}

@end
