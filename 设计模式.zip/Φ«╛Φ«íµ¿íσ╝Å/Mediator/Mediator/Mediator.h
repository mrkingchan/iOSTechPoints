//
//  Mediator.h
//  Mediator
//
//  Created by mac on 2020/7/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
@class CodingWorker;
@class TestWorker;

NS_ASSUME_NONNULL_BEGIN

@interface Mediator : NSObject

- (void)registerCoder:(CodingWorker *)coder;
- (void)registerTester:(TestWorker *)tester;

- (void)code:(NSInteger)num;
- (void)test:(NSInteger)num;

@end

NS_ASSUME_NONNULL_END
