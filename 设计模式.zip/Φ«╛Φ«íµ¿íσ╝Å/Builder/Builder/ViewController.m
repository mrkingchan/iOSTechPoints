//
//  ViewController.m
//  Builder
//
//  Created by mac on 2020/7/15.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "Worker.h"
#import "WorkerBuilder.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    Worker *a = [Worker new];
    [[[a.builder
       setAge:12]
      setName:@"Hanks"] build];
    puts(__func__);
}


@end
