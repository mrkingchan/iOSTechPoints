//
//  WorkerBuilder.h
//  Builder
//
//  Created by mac on 2020/7/15.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Worker;

NS_ASSUME_NONNULL_BEGIN

@interface WorkerBuilder : NSObject

- (instancetype)setAge:(NSInteger)age;

- (instancetype)setName:(NSString *)name;

- (instancetype)initWithWorker:(Worker *)worker;

- (Worker *)build;

@end

NS_ASSUME_NONNULL_END
