//
//  WorkerBuilder.m
//  Builder
//
//  Created by mac on 2020/7/15.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WorkerBuilder.h"
#import "Worker.h"

@interface WorkerBuilder () {
    Worker *_worker;
}

@end

@implementation WorkerBuilder

- (instancetype)initWithWorker:(Worker *)worker {
    self = [super init];
    if (self) {
        _worker = worker;
    }
    return self;
}

- (Worker *)build {
    return _worker;
}

- (instancetype)setAge:(NSInteger)age {
    [_worker setValue:@(age) forKey:@"age"];
    return self;
}

- (instancetype)setName:(NSString *)name {
    [_worker setValue:name forKey:@"name"];
    return self;
}

@end
