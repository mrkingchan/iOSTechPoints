//
//  ViewController.m
//  Composite
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "Worker.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    Worker *leftHand = [Worker new];
    Worker *rightHand = [Worker new];
    Worker *mouth = [Worker new];
    
    Worker *boss = [Worker new];
    boss.leftHand = leftHand;
    boss.rightHand = rightHand;
    boss.mouth = mouth;
}


@end
