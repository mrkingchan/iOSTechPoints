//
//  Worker.h
//  Factory
//
//  Created by mac on 2020/7/15.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

//  Worker本身也是使用工厂方法模式
@interface Worker : NSObject

//  定义创建对象的接口。（也可以定义在@protocol中）
+ (instancetype)createInstance;

@end

NS_ASSUME_NONNULL_END
