//
//  ViewController.m
//  Memento
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "Worker.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //  Caretaker
    Worker *worker = [Worker new];
    worker.name = @"Tom";
    worker.age = 11;
    [worker save];
    worker.name = @"Hanks";
    worker.age = 22;
    [worker restore];
    puts(__func__);
}


@end
