//
//  Worker.m
//  Memento
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Worker.h"
#import "Memento.h"

@interface Worker () {
    Memento *_memento;
}

@end

@implementation Worker

- (void)save {
    Worker *worker = [Worker new];
    worker.name = self.name;
    worker.age = self.age;
    _memento = [[Memento alloc] initWithState:worker];
}

- (void)restore {
    Worker *worker = [_memento state];
    self.name = worker.name;
    self.age = worker.age;
}

@end
