//
//  Memento.m
//  Memento
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Memento.h"

@interface Memento () {
    Worker *_worker;
}
@end

@implementation Memento

- (instancetype)initWithState:(Worker *)worker {
    self = [super init];
    if (self) {
        _worker = worker;
    }
    return self;
}

- (Worker *)state {
    return _worker;
}

@end
