//
//  Concrete.m
//  Template Method
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Concrete.h"

@implementation Concrete

- (void)viewDidAppear {
    puts(">>> viewDidAppear");
}

- (void)viewDidDisappear {
    puts(">>> viewDidDisappear");
}

- (void)viewWillAppear {
    puts(">>> viewWillAppear");
}

- (void)viewWillDisappear {
    puts(">>> viewWillDisappear");
}

@end
