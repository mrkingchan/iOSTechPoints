//
//  Engine.m
//  Visitor
//
//  Created by mac on 2020/7/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Engine.h"

@implementation Engine

- (void)accept:(nonnull id<Visitor>)visitor {
    [visitor visitEngine:self];
}

@end
