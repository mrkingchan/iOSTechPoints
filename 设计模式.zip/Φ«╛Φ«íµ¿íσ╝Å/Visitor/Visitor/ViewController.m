//
//  ViewController.m
//  Visitor
//
//  Created by mac on 2020/7/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "Car.h"
#import "PrintVisitor.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    Car *car = [Car new];
    PrintVisitor *visitor = [PrintVisitor new];
    [car accept:visitor];
}


@end
