//
//  ViewController.m
//  Proxy
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "Worker.h"

@interface ViewController () <WorkerDelegate> {
    Worker *_worker;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _worker = [Worker new];
    _worker.delegate = self;
    _worker.age = 13;
}

- (void)worker:(Worker *)worker didChangeAge:(NSInteger)age {
    puts(__func__);
}

@end
