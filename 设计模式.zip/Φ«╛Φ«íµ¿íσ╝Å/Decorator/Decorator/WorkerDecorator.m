//
//  WorkerDecorator.m
//  Decorator
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WorkerDecorator.h"
#import <objc/runtime.h>

@implementation WorkerDecorator

+ (void)decorate:(Worker *)worker {
    Class cls2 = [WorkerDecorator TempWorker];
    //
    object_setClass(worker, cls2);
    //
    [WorkerDecorator addWork:cls2];
}

//  生成TempWorker
+ (Class)TempWorker {
    Class cls = [Worker class];
    Class cls2 = objc_allocateClassPair(cls, "TempWorker", 0);
    objc_registerClassPair(cls2);
    return cls2;
}

//  添加work方法
+ (void)addWork:(Class)cls {
    //  "v16@0:8"
    SEL sel = @selector(work);
    IMP imp = imp_implementationWithBlock(^void(id sender) {
        puts(__func__);
    });
    class_addMethod(cls, sel, imp, "v16@0:8");
}

@end
