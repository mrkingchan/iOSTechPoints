//
//  WorkerDecorator.h
//  Decorator
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Worker.h"

NS_ASSUME_NONNULL_BEGIN

@protocol Work <NSObject>

- (void)work;

@end

@interface WorkerDecorator : NSObject

+ (void)decorate:(Worker *)worker;

@end

NS_ASSUME_NONNULL_END
