//
//  ViewController.m
//  Strategy
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "StrategyA.h"
#import "StrategyB.h"
#import "Context.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    StrategyA *a = [StrategyA new];
    StrategyB *b = [StrategyB new];
    
    Context *ctx = [Context new];
    ctx.strategy = a;
    [ctx doSomething];
    ctx.strategy = b;
    [ctx doSomething];
}


@end
