//
//  StrategyB.m
//  Strategy
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "StrategyB.h"

@implementation StrategyB

- (void)execute {
    puts(">>> StrategyB");
}

@end
