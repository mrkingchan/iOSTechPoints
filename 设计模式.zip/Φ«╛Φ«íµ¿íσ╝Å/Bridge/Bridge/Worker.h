//
//  Worker.h
//  Bridge
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Work.h"

NS_ASSUME_NONNULL_BEGIN

@interface Worker : NSObject

@property (nonatomic) NSString *name;
@property (nonatomic) NSInteger age;

- (void)work:(id<Work>)work;

@end

NS_ASSUME_NONNULL_END
