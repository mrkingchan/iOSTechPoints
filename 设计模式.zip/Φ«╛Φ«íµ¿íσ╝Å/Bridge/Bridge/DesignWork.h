//
//  DesignWork.h
//  Bridge
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Work.h"

NS_ASSUME_NONNULL_BEGIN

@interface DesignWork : NSObject <Work>

@end

NS_ASSUME_NONNULL_END
