//
//  DesignWork.m
//  Bridge
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import "DesignWork.h"

@implementation DesignWork

- (void)work:(NSString *)name age:(NSInteger)age {
    printf(">>> %s-%ld, 开始设计\n", name.UTF8String, age);
}

@end
