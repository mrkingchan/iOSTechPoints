//
//  Company.m
//  Facade
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Company.h"

@implementation Company

- (void)produce {
    [self.boss manage];
    for (Worker *worker in self.workers) {
        [worker work];
    }
}

@end
