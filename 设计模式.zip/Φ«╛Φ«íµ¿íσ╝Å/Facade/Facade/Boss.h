//
//  Boss.h
//  Facade
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Boss : NSObject

@property (nonatomic) NSString *name;
@property (nonatomic) NSInteger age;

- (void)manage;

@end

NS_ASSUME_NONNULL_END
